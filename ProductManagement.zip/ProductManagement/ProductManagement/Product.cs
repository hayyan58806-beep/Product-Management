﻿namespace ProductManagement.Models
{
    public class Product
    {
        public int Id { get; set; }          // unique
        public string Name { get; set; }
        public string Category { get; set; } // e.g., Electronics
        public double Price { get; set; }
        public int Quantity { get; set; }

        public Product()
        {
            Name = "";
            Category = "";
        }

        public Product(int id, string name, string category, double price, int quantity)
        {
            Id = id;
            Name = name ?? "";
            Category = category ?? "";
            Price = price;
            Quantity = quantity;
        }

        public double TotalValue()
        {
            return Price * Quantity;
        }

        public override string ToString()
        {
            return Id + " - " + Name;
        }
    }
}
