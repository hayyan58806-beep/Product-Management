﻿using System.Collections.Generic;
using ProductManagement.Models;

namespace ProductManagement.Data
{
    public interface IProductRepository
    {
        List<Product> Load();
        void Save(List<Product> products);
    }
}
