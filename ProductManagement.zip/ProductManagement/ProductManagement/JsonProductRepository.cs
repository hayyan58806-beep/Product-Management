﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using ProductManagement.Models;

namespace ProductManagement.Data
{
    public class JsonProductRepository : IProductRepository
    {
        private readonly string _filePath;

        public JsonProductRepository(string filePath)
        {
            _filePath = filePath;
        }

        public List<Product> Load()
        {
            try
            {
                if (!File.Exists(_filePath))
                    return new List<Product>();

                string json = File.ReadAllText(_filePath);
                var data = JsonConvert.DeserializeObject<List<Product>>(json);
                return data ?? new List<Product>();
            }
            catch
            {
                return new List<Product>();
            }
        }

        public void Save(List<Product> products)
        {
            try
            {
                string json = JsonConvert.SerializeObject(products, Formatting.Indented);
                File.WriteAllText(_filePath, json);
            }
            catch (Exception ex)
            {
                throw new Exception("Could not save file: " + ex.Message);
            }
        }
    }
}
